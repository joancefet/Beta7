<?php

 
// Translated into English by QwataKayean . All rights reversed (C) 2012
// 2Moons - Copyright (C) 2010-2012 Slaver


 
$LNG['ub_points']		= 'Pontos';
$LNG['ub_fleets']		= 'Frota';
$LNG['ub_researh']		= 'Pesquisas';
$LNG['ub_buildings']	= 'Edificios';
$LNG['ub_defenses']		= 'Defesas';

$LNG['ub_fights']		= 'Batalhas';
$LNG['ub_quote']		= 'Quote';
$LNG['ub_rank']			= 'Posição';